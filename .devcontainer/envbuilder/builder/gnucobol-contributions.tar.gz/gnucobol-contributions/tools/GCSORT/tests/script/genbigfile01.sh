##
##
export dd_outfile=../files/sqbig01.dat
## export numrek=012000000
export numrek=000000100
../bin/genbigfile
