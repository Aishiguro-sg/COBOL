cd ../script
./compile_single.sh genfiledate
./compile_single.sh checkfdate
./compile_single.sh viewfiledate


