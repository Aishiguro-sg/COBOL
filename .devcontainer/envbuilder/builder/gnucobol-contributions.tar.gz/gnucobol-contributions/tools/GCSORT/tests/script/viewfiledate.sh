##
##
## set dd_infile=../files/FDate.dat
export dd_infile=../files/FDate.dat.Y2D.srt
../bin/viewfiledate
